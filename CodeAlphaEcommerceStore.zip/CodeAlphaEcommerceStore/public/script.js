let cart = [];

function addToCart(product, price) {
  cart.push({ product, price });
  displayCart();
}

function displayCart() {
  const cartList = document.getElementById('cart');
  cartList.innerHTML = ''; // clear cart

  cart.forEach((item) => {
    const li = document.createElement('li');
    li.textContent = `${item.product} - ₹${item.price}`;
    cartList.appendChild(li);
  });
}
function submitOrder() {
  if (cart.length === 0) {
    alert('Cart is empty!');
    return;
  }

  fetch('/submit-order', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(cart)
  })
  .then(res => res.json())
  .then(data => {
    alert(data.message);
    cart = [];
    displayCart();
  })
  .catch(err => {
    alert('Error submitting order.');
    console.error(err);
  });
}
