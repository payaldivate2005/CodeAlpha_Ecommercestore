const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();

// Serve static files from public folder
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// Handle order POST
app.post('/submit-order', (req, res) => {
  const order = req.body;
  const filePath = path.join(__dirname, 'orders.json');

  fs.readFile(filePath, 'utf8', (err, data) => {
    const orders = data ? JSON.parse(data) : [];
    orders.push(order);
    fs.writeFile(filePath, JSON.stringify(orders, null, 2), () => {
      res.json({ message: 'Order received successfully!' });
    });
  });
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});